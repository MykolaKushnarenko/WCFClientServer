﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Console = System.Console;

namespace Epam
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(1);
            Console.ReadKey();
        }
    }
}
